package com.newchama.tool.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;

import com.newchama.tool.Constant;

public class AppContext {

    public static BaseApp app;
    public static boolean isDebug = true;

    private static UriInfo mUriInfo;
    private static DeviceInfo mDeviceInfo;
    private static Typeface mTypeface;

    private static Activity mActivity;

    /**
     * 是否为debug模式
     *
     * @param isDebug
     */
    private void setDebug(boolean isDebug) {
        this.isDebug = isDebug;
    }

    public static void init() {
        getUriInfo().init();
    }

    /**
     * 根据Url获取Intent
     * Url如 nc://main?from=http&id=1
     *
     * @param url
     * @return
     */
    public static Intent getIntent(String url) {
        return getUriInfo().getIntent(url);
    }

    public static UriInfo getUriInfo(){
        if (mUriInfo == null) {
            synchronized (AppContext.class) {
                if (mUriInfo == null) {
                    mUriInfo = new UriInfo();
                }
            }
        }
        return mUriInfo;
    }

    /**
     * 根据Url获取Fragment
     * Url如 nc://main?from=http&id=1
     *
     * @param url
     * @return
     */
    public static Fragment getFragment(String url) {
        return getUriInfo().getFragment(url);
    }

    /**
     * 设备信息， 包括屏幕分辨率等参数
     *
     * @return
     */
    public static DeviceInfo getDeviceInfo() {
        if (mDeviceInfo == null) {
            synchronized (AppContext.class) {
                if (mDeviceInfo == null) {
                    mDeviceInfo = new DeviceInfo();
                }
            }
        }
        return mDeviceInfo;
    }

    public static LayoutInflater getInflater() {
        return LayoutInflater.from(AppContext.app);
    }

    /**
     * 清除所有
     */
    public static void clearAll() {
        app = null;
        mUriInfo = null;
        mDeviceInfo = null;
    }

    /**
     * 清除用户相关(退出时清除)
     */
    public static void clear(){
        setActivity(null);
    }

    /**
     * 登录页面
     */
    public static void goLogin() {
        AppContext.app.startActivity(AppContext.getIntent(Constant.URI_LOGIN));
    }

    /**
     * 用户支持页面
     */
    public static void goSupport() {
        AppContext.app.startActivity(AppContext.getIntent(Constant.URI_SUPPORT));
    }

    /**
     * 获取自定义字体
     * @return
     */
    public static Typeface getTypeface() {
        if (mTypeface == null) {
            mTypeface = Typeface.createFromAsset(app.getAssets(), "pt_din_condensed_cyrillic.ttf");
        }
        return mTypeface;
    }

    public static Activity getActivity() {
        return mActivity;
    }

    public static void setActivity(Activity mActivity) {
        AppContext.mActivity = mActivity;
    }
}

package com.newchama.tool.secure;

/**
 * 第三方加密库
 * https://github.com/RNCryptor
 * https://github.com/RNCryptor/JNCryptor
 *
 * Created by ncm on 16/4/25.
 */
public class RNCryptor {

    /**
     * 加密
     * @param content
     * @param password
     * @return
     *//*
    public static byte[] encrypt(String content, String password){
        try {
            org.cryptonode.jncryptor.JNCryptor cryptor = new AES256JNCryptor();
            return cryptor.encryptData(content.getBytes(), password.toCharArray());
        } catch (CryptorException e) {
            // Something went wrong
            e.printStackTrace();
        }
        return null;
    }

    *//**
     * 解密
     * @param content
     * @param password
     * @return
     *//*
    public static byte[] decrypt(byte[] content, String password){
        try {
            org.cryptonode.jncryptor.JNCryptor cryptor = new AES256JNCryptor();
            return cryptor.encryptData(content, password.toCharArray());
        } catch (CryptorException e) {
            // Something went wrong
            e.printStackTrace();
        }
        return null;
    }*/

}

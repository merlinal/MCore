package com.newchama.tool.secure;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES 加密 & 解密
 *
 */
public class AES {
	private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
	private static final String ALGORITHM_NAME = "AES";

	/* 加密模式和填充方式
	加密方式/工作模式/填充模式       16字节加密后数据长度        不满16字节加密后长度
	AES/CBC/NoPadding             16                          不支持
	AES/CBC/PKCS5Padding          32                          16
	AES/CBC/ISO10126Padding       32                          16
	AES/CFB/NoPadding             16                          原始数据长度
	AES/CFB/PKCS5Padding          32                          16
	AES/CFB/ISO10126Padding       32                          16
	AES/ECB/NoPadding             16                          不支持
	AES/ECB/PKCS5Padding          32                          16
	AES/ECB/ISO10126Padding       32                          16
	AES/OFB/NoPadding             16                          原始数据长度
	AES/OFB/PKCS5Padding          32                          16
	AES/OFB/ISO10126Padding       32                          16
	AES/PCBC/NoPadding            16                          不支持
	AES/PCBC/PKCS5Padding         32                          16
	AES/PCBC/ISO10126Padding      32                          16
	*/

	/**
	 * 加密
	 * @param content
	 * @param key
	 * @param iv
	 * @param mode
     * @return
     */
	public static byte[] encrypt(String content, String key, String iv, String mode){
		try {
			SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), ALGORITHM_NAME);
			IvParameterSpec ivSpec = new IvParameterSpec(iv.getBytes());
			Cipher cipher = Cipher.getInstance(mode);
			byte[] byteContent = content.getBytes("utf-8");
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
			byte[] result = cipher.doFinal(byteContent);
			return result;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e){
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] encrypt(String content, String key, String iv) {
		return encrypt(content, key, iv, TRANSFORMATION);
	}

	/**
	 * 解密
	 * @param content
	 * @param key
	 * @param iv
	 * @param mode
     * @return
     */
	public static byte[] decrypt(byte[] content, String key, String iv, String mode) {
		try {
			SecretKeySpec localSecretKeySpec = new SecretKeySpec(key.getBytes(), ALGORITHM_NAME);
			Cipher cipher = Cipher.getInstance(mode);
			IvParameterSpec localIvParameterSpec = new IvParameterSpec(iv.getBytes());
			cipher.init(Cipher.DECRYPT_MODE, localSecretKeySpec, localIvParameterSpec);
			byte[] arrayOfByte = cipher.doFinal(content);
			return arrayOfByte;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e){
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] decrypt(byte[] content, String key, String iv) {
		return decrypt(content, key, iv, TRANSFORMATION);
	}

	public static byte[] encrypt2(String content, String key, String mode) {
		try {
			SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), ALGORITHM_NAME);
			Cipher cipher = Cipher.getInstance(mode);
			byte[] byteContent = content.getBytes("utf-8");
			cipher.init(Cipher.ENCRYPT_MODE, keySpec);
			byte[] result = cipher.doFinal(byteContent);
			return result;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] decrypt(byte[] content, String password) {
		try {
			SecretKeySpec key = new SecretKeySpec(getKey(password), ALGORITHM_NAME);
			Cipher cipher = Cipher.getInstance(ALGORITHM_NAME);
			cipher.init(Cipher.DECRYPT_MODE, key);
			byte[] result = cipher.doFinal(content);
			return result;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] getKey(String key) {
		byte[] b = new byte[16];
		byte[] keyBytes = key.getBytes();
		int len = (keyBytes.length < 16) ? keyBytes.length : 16;
		for (int i = 0; i < len; ++i) {
			b[i] = keyBytes[i];
		}
		return b;
	}

}

package com.newchama.tool.secure;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by ncm on 16/3/22.
 */
public class MD5 {

    /**
     * md5
     * @param str
     * @return
     */
    public static String getMD5(String str){
        MessageDigest messageDigest = null;
        StringBuffer md5StrBuff = null;
        try {
            md5StrBuff = new StringBuffer();
            messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.reset();
            messageDigest.update(str.getBytes("UTF-8"));
            for(byte b : messageDigest.digest()) {
                md5StrBuff.append(String.format("%02x", b & 0xff));
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return md5StrBuff.toString();
    }

}

package com.newchama.tool.app;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.google.gson.reflect.TypeToken;
import com.newchama.tool.app.host.UriVo;
import com.newchama.tool.util.JsonUtil;
import com.newchama.tool.util.LogUtil;
import com.newchama.tool.util.Util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by ncm on 16/3/17.
 */
public class UriInfo {

    private final String URI_PRE = "ncm://";

    private Map<String, String> uriMatcherForActivity = new HashMap<String, String>();

    public void init() {
        loadUriMatcher(AppContext.app.getPackageName(), AppContext.app.getResources());
    }

    private void loadUriMatcher(String packageName, Resources res) {
        try {
            ApplicationInfo appInfo = AppContext.app.getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);
            LogUtil.i("AppContext", "初始化host");
            if (appInfo != null && appInfo.metaData != null) {
                Bundle metaDataBundle = appInfo.metaData;
                Set<String> set = metaDataBundle.keySet();
                if (set != null) {
                    for (String string : set) {
                        if ((string != null) && (string.startsWith("ncm_uri_"))) {
                            LogUtil.e(string + "===" + metaDataBundle.get(string));
                            int rawResId = metaDataBundle.getInt(string);
                            List<UriVo> uriVOList = null;
                            try {
                                StringBuffer sb = new StringBuffer();
                                String str;
                                BufferedReader br = new BufferedReader(getStreamReader(res.openRawResource(rawResId)));
                                while ((str = br.readLine()) != null) {
                                    sb.append(str);
                                }
                                uriVOList = JsonUtil.toList(sb.toString(), new TypeToken<List<UriVo>>() {
                                }.getType());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (uriVOList != null) {
                                for (UriVo uriVo : uriVOList) {
                                    LogUtil.i("AppContext", uriVo.host + ";" + uriVo.name);
                                    uriMatcherForActivity.put(uriVo.host, uriVo.name);
                                }
                            }
                        }
                    }
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            LogUtil.e("AppContext", e.toString());
        } catch (Exception e) {
            LogUtil.e("AppContext", e.toString());
        }
    }

    public InputStreamReader getStreamReader(InputStream ins) {
        if (ins != null) {
            try {
                return new InputStreamReader(ins, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                LogUtil.e("AppContext", e.toString());
            }
        }
        return null;
    }

    public Intent getIntent(String url) {
        Intent it = null;
        String classpath = getClassPath(url);
        if (classpath != null) {
            it = new Intent(AppContext.app, Util.loadClass(classpath));
            //参数
            it.putExtras(getParams(url));
        }
        it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        return it;
    }

    public Fragment getFragment(String url) {
        Fragment fragment = null;
        String classpath = getClassPath(url);
        if (classpath != null) {
            try {
                fragment = (Fragment) Util.loadClass(classpath).newInstance();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            //参数
            fragment.setArguments(getParams(url));
        }
        return fragment;
    }

    private String getClassPath(String url) {
        //目标类
        String key = url;
        int index = url.indexOf("?");
        if (index > 0) {
            key = url.substring(0, index);
        }
        key = key.replace(URI_PRE, "");
        return uriMatcherForActivity.get(key);
    }

    public Bundle getParams(String url) {
        Bundle bundle = new Bundle();
        Uri uri = Uri.parse(url);
        String paramStr = uri.getQuery();
        if (paramStr != null && paramStr.length() > 0) {
            String[] params = paramStr.split("&");
            for (String param : params) {
                String[] nameValues = param.split("=");
                if (nameValues.length > 1) {
                    bundle.putString(nameValues[0], nameValues[1]);
                }
            }
        }
        return bundle;
    }

}